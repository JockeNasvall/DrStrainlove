#!/bin/bash
set -euo pipefail

DEST_DIR="/var/backups/mysql"
RETENTION_DAYS=14
LOG_FILE="/var/log/mysql_backup.log"
GZIP_LEVEL=6
PHP_CRED_FILE="/var/www/strainlove/db.php"

log() {
  local ts
  ts="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  printf '%s %s\n' "$ts" "$*" | tee -a "$LOG_FILE" >&2
}

fail() {
  log "ERROR: $*"
  [[ -n "${RUN_DIR:-}" && -d "${RUN_DIR:-}" ]] && rm -rf "$RUN_DIR"
  exit 1
}

[[ -r "$PHP_CRED_FILE" ]] || fail "Cannot read PHP creds at $PHP_CRED_FILE"

dump_bin=""
if command -v mariadb-dump >/dev/null 2>&1; then
  dump_bin="mariadb-dump"
elif command -v mysqldump >/dev/null 2>&1; then
  dump_bin="mysqldump"
else
  fail "mysqldump/mariadb-dump not found"
fi

mkdir -p "$DEST_DIR" || fail "Cannot create $DEST_DIR"
touch "$LOG_FILE" || fail "Cannot write $LOG_FILE"

php_val() {
  local var="$1"
  perl - "$var" "$PHP_CRED_FILE" <<'PL' || exit 1
use strict;
use warnings;
my ($v, $file) = @ARGV;
open my $fh, "<", $file or die "open $file: $!";
local $/;
my $s = <$fh>;
if ($s =~ /\$\Q$v\E\s*=\s*['"]([^'"]+)['"]\s*;/s) {
  print "$1\n";
  exit 0;
}
exit 1;
PL
}

DB_USER="$(php_val dbuser)"
DB_PASS="$(php_val dbpassword)"
DB_NAME="$(php_val dbname)"
DB_HOST="$(php_val hostname)"

DATE_UTC="$(date -u '+%Y%m%dT%H%M%SZ')"
RUN_DIR="${DEST_DIR%/}/$DATE_UTC"

mkdir -p "$RUN_DIR" || fail "Cannot create $RUN_DIR"

LOCK_FILE="${DEST_DIR%/}/.mysql_backup.lock"
exec 9>"$LOCK_FILE" || fail "Cannot open $LOCK_FILE"

flock -n 9 || fail "Another backup is running"

TMP_CNF="$(mktemp "${RUN_DIR%/}/.myXXXXXX.cnf")"
chmod 600 "$TMP_CNF"

cat >"$TMP_CNF" <<EOF
[client]
user=$DB_USER
password=$DB_PASS
host=$DB_HOST
EOF

OUTFILE="${RUN_DIR}/${DB_NAME}_${DATE_UTC}.sql.gz"

if ! "$dump_bin"   --defaults-extra-file="$TMP_CNF"   --single-transaction   --quick   --routines   --triggers   --events   --set-gtid-purged=OFF   --default-character-set=utf8mb4   --databases "$DB_NAME"   2>>"$LOG_FILE" | gzip "-${GZIP_LEVEL}" > "$OUTFILE"; then
  rm -f "$OUTFILE"
  fail "Dump failed"
fi

gzip -t "$OUTFILE" || fail "gzip verification failed"

shred -u "$TMP_CNF" || rm -f "$TMP_CNF"

ln -sfn "$RUN_DIR" "${DEST_DIR%/}/latest"

find "$DEST_DIR" -mindepth 1 -maxdepth 1 -type d -not -name 'latest' -mtime +"$RETENTION_DAYS" -exec rm -rf {} \; || true

log "Backup complete: $OUTFILE"
