# MySQL Backup Service

Automated daily MySQL/MariaDB backups using systemd.

Features:
- Reads credentials from `/var/www/strainlove/db.php`
- Creates compressed `.sql.gz` backups
- Rotates old backups automatically
- Updates a `latest` symlink
- Runs headless via systemd timer
- Survives reboot automatically

## Included Files

- mysql_backup.sh
- mysql-backup.service
- mysql-backup.timer
- install.sh

## Install

Extract:

```bash
tar -xzf mysql-backup-fixed-bundle-*.tar.gz
cd mysql-backup-fixed-bundle
```

Install:

```bash
chmod +x install.sh
./install.sh install
```

## Verify

```bash
sudo ls -lh /var/backups/mysql/latest
gzip -t /var/backups/mysql/latest/*.sql.gz && echo OK
```

## Restore

```bash
DUMP=$(ls -1 /var/backups/mysql/latest/*.sql.gz | head -n1)
gunzip -c "$DUMP" | mysql -h localhost -u root -p
```

## Logs

```bash
sudo journalctl -u mysql-backup.service -n 100 --no-pager
```

## Manual Run

```bash
sudo systemctl start mysql-backup.service
```

## Uninstall

```bash
./install.sh uninstall
```

Backups/logs are preserved.
