#!/bin/bash
set -euo pipefail

ACTION="${1:-install}"

install_all() {
  sudo install -m 0755 mysql_backup.sh /usr/local/bin/mysql_backup.sh
  sudo sed -i 's/\r$//' /usr/local/bin/mysql_backup.sh

  sudo mkdir -p /var/backups/mysql
  sudo touch /var/log/mysql_backup.log

  sudo chown root:root /var/backups/mysql /var/log/mysql_backup.log
  sudo chmod 750 /var/backups/mysql
  sudo chmod 640 /var/log/mysql_backup.log

  sudo install -m 0644 mysql-backup.service /etc/systemd/system/mysql-backup.service
  sudo install -m 0644 mysql-backup.timer /etc/systemd/system/mysql-backup.timer

  sudo systemctl daemon-reload
  sudo systemctl enable --now mysql-backup.timer

  sudo rm -f /var/backups/mysql/.mysql_backup.lock || true
  sudo systemctl start mysql-backup.service

  echo
  echo "Latest backup:"
  sudo ls -lh /var/backups/mysql/latest || true

  echo
  echo "Recent logs:"
  sudo journalctl -u mysql-backup.service -n 20 --no-pager || true
}

case "$ACTION" in
  install) install_all ;;
  uninstall)
    sudo systemctl disable --now mysql-backup.timer || true
    sudo rm -f /etc/systemd/system/mysql-backup.service
    sudo rm -f /etc/systemd/system/mysql-backup.timer
    sudo systemctl daemon-reload
    sudo rm -f /usr/local/bin/mysql_backup.sh
    echo "Uninstalled."
    ;;
esac
