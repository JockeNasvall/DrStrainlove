# MySQL Backup Service (with Google Drive)

Automated daily MySQL/MariaDB backups using systemd with cloud synchronization.

Features:
- Reads credentials from /var/www/strainlove/db.php
- Creates compressed .sql.gz backups
- Syncs successful backups to Google Drive via rclone
- Rotates old local backups (14-day retention)
- Updates a latest symlink
- Runs headless via systemd timer
- Survives reboot automatically

## Prerequisites

1. Install rclone:
sudo apt update && sudo apt install rclone -y

2. Configure Google Drive:
Run the following as your normal user and follow the prompts. Name the remote "gdrive".
rclone config

3. Transfer Config to Root:
Since the service runs as root, copy your config:
sudo mkdir -p /root/.config/rclone
sudo cp ~/.config/rclone/rclone.conf /root/.config/rclone/rclone.conf

## Included Files

- mysql_backup.sh
- mysql-backup.service
- mysql-backup.timer
- install.sh

## Install

Extract:
tar -xzf mysql-backup-gdrive-bundle.tar.gz
cd mysql-backup-gdrive-bundle

Install:
chmod +x install.sh
sudo ./install.sh install

## Verify
sudo ls -lh /var/backups/mysql/latest
gzip -t /var/backups/mysql/latest/*.sql.gz && echo OK

## Restore
DUMP=$(ls -1 /var/backups/mysql/latest/*.sql.gz | head -n1)
gunzip -c "$DUMP" | mysql -h localhost -u root -p

## Logs
sudo journalctl -u mysql-backup.service -n 100 --no-pager

## Manual Run
sudo systemctl start mysql-backup.service

## Uninstall
./install.sh uninstall

Backups/logs are preserved.
